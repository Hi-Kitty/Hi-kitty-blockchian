import { create, get, getAll, getByTime } from "./service/blockchianService.js";


export const handler = async(event) => {
    console.log("request: ", JSON.stringify(event, undefined, 2));
    let body;
    try {
        switch (event.httpMethod) {
            case "GET":
                if (event.queryStringParameters != null) {
                    body = await getByTime(event);
                }
                else if (event.pathParmeters != null) {
                   body =  await get(event.pathParameters.key);
                } else {
                    body = await getAll();
                }
                break;
            case "POST":
                body = await create(event);
                break;
            default:
                throw new Error(`Unsupported method "${event.httpMethod}"`)
        }
        console.log("body: ", body);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: `Success ${event.httpMethod} method`,
                body: body
            })
        };
    } catch (error) {
        console.log("error: ", error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: `Error ${event.httpMethod} method`,
                errorMsg: error.message,
                errorStack: error.stack
            })
        };
    }
};