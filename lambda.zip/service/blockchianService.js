
import {getBalance, addTransaction} from "../respository/chain.js"
import { get, getAll, getByTime, create } from "../respository/dynamodb.js";

class ChainService {
    
    constructor() {
    
    }
  
    async save(event) {
      const { key, donorName, fundraiserName, timestamp, amount } = event.body;
      const result = await create(event);
      await addTransaction(key, donorName, fundraiserName, timestamp, amount);
      return result;
    }
  
    async get(key) {
        const result1 = await get(key);
      const result2 = await getBalance(key)
      console.log(result1);
    console.log(result2);
      return result1;
    }

    async getAll() {
        const result = await getAll();
        return result;
    }

    async getByTime(event) {
        const result = await getByTime(event);
        return result;
    }
  }
  
  const chainService = new ChainService();
  
  export { chainService };
  